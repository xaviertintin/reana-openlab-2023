#!/bin/bash

# Path to the log file
LOG_FILE="pod_counts.log"
MINUTE=1

while true; do
    echo "Minute$MINUTE: $(date +%Y-%m-%dT%H:%M:%S) submit-first pods count:" >> "$LOG_FILE"
    kubectl get pods | grep submit-first | grep -v STATUS | awk '{print $3}' | sort | uniq -c | sort -rn | head -20 | awk '!max{max=$1;}{r="";i=s=60*$1/max;while(i-->0)r=r"#"; printf "%25s %5d %s %s",$2,$1,r,"\n";}' >> "$LOG_FILE"

    echo "Minute$MINUTE: $(date +%Y-%m-%dT%H:%M:%S) submit-second pods count:" >> "$LOG_FILE"
    kubectl get pods | grep submit-second | grep -v STATUS | awk '{print $3}' | sort | uniq -c | sort -rn | head -20 | awk '!max{max=$1;}{r="";i=s=60*$1/max;while(i-->0)r=r"#"; printf "%25s %5d %s %s",$2,$1,r,"\n";}' >> "$LOG_FILE"

    ((MINUTE++))
    sleep 60  # Sleep for 60 seconds
done
