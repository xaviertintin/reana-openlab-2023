import pandas as pd
from datetime import datetime

columns = ['JOB_NAME', 'TIME', 'EVENT_TYPE']
df_job = pd.read_csv('job_event_log.txt', sep=';', names=columns, header=None)

columns = ['POD_NAME', 'TIME', 'PHASE']
df_pod = pd.read_csv('output.txt', sep=';', names=columns, header=None)

def results(text):
    parts = text.split(':')
    return parts[-1].strip()

def transform_format_pod(date_hour):
    index_space = date_hour.index(':')
    date_hour = date_hour[index_space+1:]
    date_hour= date_hour.strip()
    format_input = "%Y-%m-%d %H:%M:%S"
    format_output = "%Y-%m-%dT%H:%M:%S"
    date_hour = datetime.strptime(date_hour, format_input)
    return date_hour.strftime(format_output)

def transform_format_job(date_hour):
    index_space = date_hour.index(':')
    date_hour = date_hour[index_space+1:]
    date_hour= date_hour.strip()
    format_input = "%Y-%m-%d %H:%M:%S.%f"
    format_output = "%Y-%m-%dT%H:%M:%S"
    date_hour = datetime.strptime(date_hour, format_input)
    return date_hour.strftime(format_output)

def transform_format(date_hour):
    index_space = date_hour.index(':')
    date_hour = date_hour[index_space+1:]
    date_hour= date_hour.strip()
    format_input = "%Y-%m-%d %H:%M:%S.%f"
    format_output = "%Y-%m-%dT%H:%M:%S"
    date_hour = datetime.strptime(date_hour, format_input)
    return date_hour.strftime(format_output)

df_job_1 = df_job[['JOB_NAME', 'EVENT_TYPE']].applymap(results)
df_job_2 = df_job[['TIME']].applymap(transform_format_job)

df_pod_1 = df_pod[['POD_NAME', 'PHASE']].applymap(results)
df_pod_2 = df_pod[['TIME']].applymap(transform_format_pod)

df_job_combined = df_job_1.join(df_job_2)
df_pod_combined = df_pod_1.join(df_pod_2)

columns = ["name", "run_number", "created","started","ended","status","asked_to_start_date","collected_date"]
workflowData=pd.DataFrame(columns=columns)


def extract_elements(input_string):
    elements = input_string.split("-")
    return elements[1].strip(), elements[2].strip()

for index in df_job_combined.index:
    #print(f"{df_combined['JOB_NAME'][index]}, {df_combined['EVENT_TYPE'][index]},{df_combined['TIME'][index]}")
    job, workflow = extract_elements(df_job_combined['JOB_NAME'][index])
    workflowName="workflow-"+workflow
    if (job=="firstjob") & (df_job_combined['EVENT_TYPE'][index].strip()=="Job added to the cluster."):
      #print("->Created")
      new_row = [workflowName, 1, df_job_combined['TIME'][index] ,"started","ended","finished","asked_to_start_date","2023-08-20T14:10:00"]
      workflowData = workflowData.append(pd.Series(new_row, index=columns), ignore_index=True)
      
      condition = workflowData["name"] == workflowName
      row_index = workflowData.index[condition][0]
      if workflowData.loc[row_index, "asked_to_start_date"] == "asked_to_start_date":
          workflowData.loc[row_index, "asked_to_start_date"] = df_job_combined['TIME'][index]


for index in df_pod_combined.index:
    #print(f"{df_combined['JOB_NAME'][index]}, {df_combined['EVENT_TYPE'][index]},{df_combined['TIME'][index]}")
    job, workflow = extract_elements(df_pod_combined['POD_NAME'][index])
    workflowName="workflow-"+workflow

    if (job=="firstjob") & (df_pod_combined['PHASE'][index].strip()=="Running"):
      #print("->Started")
      condition = workflowData["name"] == workflowName
      row_index = workflowData.index[condition][0]
      if workflowData.loc[row_index, "started"] == "started":
          workflowData.loc[row_index, "started"] = df_pod_combined['TIME'][index]

    elif (job=="firstjob") & (df_pod_combined['PHASE'][index].strip()=="Succeeded"):
      #print("->Started")
      condition = workflowData["name"] == workflowName
      row_index = workflowData.index[condition][0]
      if workflowData.loc[row_index, "ended"] == "ended":
          workflowData.loc[row_index, "ended"] = df_pod_combined['TIME'][index]
    
workflowData.to_csv('kueue_collected_results.csv', index=False)