from datetime import datetime, timedelta

# Open input and output files
with open('test.txt', 'r') as input_file, open('output.txt', 'w') as output_file:
    for line in input_file:
        if 'Time:' in line:
            parts = line.split(';')
            timestamp = parts[1].strip().split(': ')[1]
            old_time = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S')
            new_time = old_time + timedelta(hours=2)
            new_timestamp = new_time.strftime('%Y-%m-%d %H:%M:%S')
            modified_line = f"{parts[0]}; Time: {new_timestamp} ; {parts[2]}"
            output_file.write(modified_line)
        else:
            output_file.write(line)
