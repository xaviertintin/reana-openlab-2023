from kubernetes import client, config, watch
from datetime import datetime

config.load_kube_config()

v1 = client.BatchV1Api()
w = watch.Watch()

output_file = "job_event_log.txt"  # Change this to the desired output file path

with open(output_file, "a") as f:
    for event in w.stream(v1.list_namespaced_job, namespace="default", watch=True):
        event_type = event['type']
        job_name = event['object'].metadata.name

        event_info = {
            "JOB_NAME": job_name,
            "; TIME": str(datetime.now()),
            "; EVENT_TYP": event_type
        }

        if event_type == "ADDED":
            event_info["STATE"] = "Job added to the cluster."

        elif event_type == "MODIFIED":
            if event['object'].status.active == 1:
                event_info["STATE"] = "Job is pending."

            elif event['object'].status.succeeded == 1:
                event_info["STATE"] = "Job has finished successfully."

        event_info_str = "".join([f"{key}: {value}" for key, value in event_info.items()])
        f.write(event_info_str+ "\n")